--고정 가상계좌 입금
-- 입금내역 : 복권 예치금
-- 금액 : 5000 ~ 
-- 계좌주명 : 동행복권_홍길동

CREATE TABLE Deposit(
title varchar2(30));

SELECT TABLE Deposit;

CREATE TABLE Depositinfo(
	depositH varchar2(20), --입금내역
	price NUMBER, -- 금액
	bankName varchar2(22) -- 계좌주명
);

INSERT INTO Deposit values('복권예치금'
	,20000,'동행복권_홍길동');

SELECT depositH 입금내역, price 금액, bankName 계좌주명 
		FROM Deposit;
	
		SELECT * FROM Deposit;
					
	
DROP TABLE Deposit;


DROP table Chargeinfo;
CREATE TABLE Chargeinfo(
	orderNum varchar2(100), --주문번호
	insertM  varchar2(100), -- 결제 금액
	bankName varchar(100), -- 계좌주명(ID)
	virAccount varchar2(100), -- 고정 가상계좌
	payMethod varchar2(100), -- 결제방식
	issuDate timestamp -- 발급 일시
);

INSERT INTO Chargeinfo VALUES ('2021062009','5000원','동행복권_홍길동',
'[케이뱅크]701-0303-637-8522', '고정계좌 입금', '2021/06/20 09:05:02');
SELECT * FROM Chargeinfo;
