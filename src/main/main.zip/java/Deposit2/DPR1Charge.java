package Deposit2;

public class DPR1Charge {

	private String orderNum; // 주문번호,
	private int orderPrice; // 결제금액
	private String bankId; // 계좌주명(ID)
	private String  vAccount; // 고정가상계좌
	private String payMethod; // 결제 방식
	private String issueDate; // 발급일시
	
}

/*
[1] 예치금 조회 [2] 충전하기 [3] 출금신청 [4] 종료
 */
