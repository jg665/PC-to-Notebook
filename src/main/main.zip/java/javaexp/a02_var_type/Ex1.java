package javaexp.a02_var_type;

import java.util.Scanner;

public class Ex1 {
	
//		public static void times(double a, double b) {
//			System.out.println(a*b);
//		}
//	public static void printsquare(int x) {
//		System.out.println(x * x);
//	}
	
	
//	
//	public static double square(double x) {
//		return x* x;
//	}
//	
//	
//	 	static int autoseller(int inmoney) {
//		int rest = inmoney-900;
//		if(rest<0) {
//			System.out.println("돈이부족합니다");
//			System.out.println("콜라 지급 안됨");
//		}else {
//			System.out.println("콜라입니다");
//		}
//		return rest;
//		
//	}
//	
	
//	public static void sum(int left, int right) {
//		System.out.println(left + right);
//	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		Scanner sc = new Scanner(System.in);
//		System.out.println("국어 점수를 입력하세요:");
//		int kor = sc.nextInt();
//		System.out.println("영어 점수를 입력하세요:");
//		int eng = sc.nextInt();
//		if(kor>=80) {
//			if(eng>=80) {
//				System.out.println("국어와 영어점수가 80점 이상일때:"+"A");
//			}else {
//				System.out.println("국어만 80점 이상일경우 :" +"B");
//			}
//			}else { // 국어점수가 80이상이 아닐때
//				if(eng>=80) {
//					System.out.println("영어만 80점 이상일경우:"+"C");
//			}else {
//				System.out.println("영어와 국어점수 모두 80점 미만일때"+"D");
//				}
//			}
			}
		}
		
		
//		times(2, 2);
//		times(5, 3);
		
//		int value = 2;
//		printsquare(value);
//		printsquare(10);
//		printsquare(value * 3);
//		
//		System.out.println(square(5));
//		System.out.println(square(2));
		
//		System.out.println(2000);
//		System.out.println(1000);
		
//		sum(10,30);
//		sum(500,200);
		
//	}
//}
