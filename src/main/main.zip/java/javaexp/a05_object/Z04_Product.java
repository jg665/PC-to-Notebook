package javaexp.a05_object;

class Z04_Product {
	
	private Z04_Product(){
		
		System.out.println("생성자!!");
	}

}
