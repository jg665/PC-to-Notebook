package javaexp.a05_object;

public class Z02_Bus {
	// 버스 번호
	int no;
	// 구간
	String from;
	String to;
	
	
}
