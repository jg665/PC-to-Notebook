package javaexp.a05_object.vo;

public class Product2 {
	String name;
	int price;
	int cnt;
	
	public Product2() {
		super();
	}

	public Product2(String name) {
		super();
		this.name = name;
	}
	
	public Product2(String name, int price, int cnt) {
		super();
		this.name = name;
		this.price = price;
		this.cnt = cnt;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public int getCnt() {
		return cnt;
	}
	public void setCnt(int cnt) {
		this.cnt = cnt;
	}
	
	@Override
	public String toString() {
		return super.toString()+"Product2 [name=" + name + ", price=" + price 
				+ ", cnt=" + cnt + ", 총계="+(price*cnt)+"]";
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Product2 p2 = new Product2();
		System.out.println (p2);
		
	}
	

}
