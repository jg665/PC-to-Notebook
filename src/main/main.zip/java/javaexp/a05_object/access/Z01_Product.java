package javaexp.a05_object.access;

public class Z01_Product {
//	접근제어자가 붙지 않을 때는 , default 이고
//	default는 같은 패키지 내애서만 접근이 가능하다.
	public Z01_Product(){
		System.out.println("매개변수 없는 생성자");
	}
	
}
