package javaexp.z05_project;

public class Z99_Program {
    public static void main(String[] args) {
        Z99_MemberJoinDAO memberJoinDAO = new Z99_MemberJoinDAO();
        memberJoinDAO.run();
    }
}

