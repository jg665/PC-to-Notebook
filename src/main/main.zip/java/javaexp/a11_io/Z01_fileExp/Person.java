package javaexp.a11_io.Z01_fileExp;

public class Person {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("복사 및 삭제");
	}

}
