package javaexp.a11_io;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;

public class A17_FileWriter {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
/*
ex) javaexp\all_io\z01_fileExp\Person.java
		A16_TextReaderExp.java를 만들고
		파일의 내용을 읽어와서 출력하세요. 4조
		
	*/
/*
# File쓰기 처리.
1. 주요 처리 절차
	1) 대상 File 지정
	2) System.in으로 입력 처리 
		InputStream ==> InputStreamReader ==> BufferedReader
	3)	PrintWriter를 이용해서 출력처리 객체를 활용..
	4)	File ==> FileWriter ==> PrintWriter 
		입력된 내용을 PrintWriter의 out.print()를 활용해서 출력 처리.
 */
		BufferedReader buffer = new BufferedReader(
				new InputStreamReader(System.in));
		System.out.println("#입력할 내용#");
		PrintWriter out=null;
		try {
//			System.out.println(buffer.readLine());
//			 1. 출력할 File객체 생성
			String path= "C:\\javaexp\\workspace\\javaexp\\src\\main\\java\\javaexp\\a11_io\\z02_fileExp";
			String fname="show.txt";
			File f = new File(path,fname);
			FileWriter writer = new FileWriter(f);
			out = new PrintWriter(writer);
			// 해당 파일에 쓰기 처리..
			out.print(buffer.readLine());
			System.out.println("출력 종료!!");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				buffer.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			out.close();
		}
				
	}
}
