package javaexp.z01_vo;

public class Bus {

}
