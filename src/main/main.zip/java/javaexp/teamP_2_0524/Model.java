package javaexp.teamP_2_0524;

public class Model {
	public void addAttribute(String key, Object ob) {
		//System.out.println("*** ( 모델 데이터 처리 )");
		//System.out.println("*** (key:"+key+", 객체: "+ob.getClass().getSimpleName()+")");
	}
}
