package javaexp.ProjectOOP;

public class MethodDemo1 {

//		public static void numbering() {
//			int i = 0;
//			while (i < 10) {
//				System.out.println(i);
//				i++;
//			}
//		}
	
	
		public static void nuber() {
			for(int i=0; i<=10; i++ ) {
				System.out.println("1~10 "+i);
			}
		}
		public static void main(String[] args) {
			// TODO Auto-generated method stub
			nuber();
	}

}
