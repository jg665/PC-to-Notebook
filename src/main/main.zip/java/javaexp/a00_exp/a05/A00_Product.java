package javaexp.a00_exp.a05;

class A00_Product {

		private A00_Product(){
			System.out.println("생성자!!");
		}
	}

