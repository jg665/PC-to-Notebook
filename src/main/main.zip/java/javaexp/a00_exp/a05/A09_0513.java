package javaexp.a00_exp.a05;

public class A09_0513 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
/*		
1. java프로그램을 작성한 후, 컴파일 과정과 실행과정을 main()와의 관계 속에서 기술하세요
	1) 실행명령어 위치기술, 컴파일 파일 위치기술
	
	2) A01_Start.java 기준을 main()가 있을때와 없을때의 차이점
	main()메서드가 있
	3) 컴파일 실행 파일 만들어 지는 과정


*/	

	}

}
