package javaexp.z01_vo;

public class Fruits {
	private String name;
	private String kind;
	public Fruits() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Fruits(String name, String kind) {
		super();
		this.name = name;
		this.kind = kind;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getKind() {
		return kind;
	}
	public void setKind(String kind) {
		this.kind = kind;
	}
	
}
