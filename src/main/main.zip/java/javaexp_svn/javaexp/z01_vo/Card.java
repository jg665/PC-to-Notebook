package javaexp.z01_vo;

public class Card {
 public String shape;
 public String num;
public Card() {
	super();
	// TODO Auto-generated constructor stub
}
public Card(String shape, String num) {
	super();
	this.shape = shape;
	this.num = num;
}
public String getShape() {
	return shape;
}
public void setShape(String shape) {
	this.shape = shape;
}
public String getNum() {
	return num;
}
public void setNum(String num) {
	this.num = num;
}
 
}
