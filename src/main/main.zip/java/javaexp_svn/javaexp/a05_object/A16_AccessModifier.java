package javaexp.a05_object;


public class A16_AccessModifier {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Z04_Product p1 = null; // 1. 선언
//		p1 = new Z04_Product(); // 2. 객체 생성
		// 생성자 private이기에 외부 package에서 접근 불가하다.
/*		
		Z01_Product p2 = null; ==> 접근제어자 class 클래스명{}
		p2 = new Z01_Product();
			==> class 클래스명{ 생성자(){}}
			// 접근제어자 class 클래스명{}

								 */
	}

}
