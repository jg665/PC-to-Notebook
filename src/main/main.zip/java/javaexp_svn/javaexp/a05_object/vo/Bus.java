package javaexp.a05_object.vo;

public class Bus {

}
