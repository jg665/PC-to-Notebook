package javaexp.a05_object.vo;

public class Bang {
	public String name;
	public int birth;
	public String pet;
	
	public Bang(String name, int birth, String pet) {
		this.name = name;
		this.birth = birth;
		this.pet = pet;
	}
	
}
