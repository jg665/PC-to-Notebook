package javaexp.a05_object;

public class Z03_Computer {
	String name;
	int cpu;
	int ram;
	// 클래스 선언하면 default 생성자가 내부적으로 선언되어 있다.
	// 생성자를 선언하지 않으면 아래와 같이 선언되어 있다.
	// Z03_Computer com1 = new Z03_Computer();
	// 기본적으로 사용이 가능하다.
	public Z03_Computer() {}
}
