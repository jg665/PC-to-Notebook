package javaexp.a00_exp.z01_vo;

public class Person {
	/*
	보이지 않는 default 생성자의 선언 모양
	public Person(){}	
		*/
	public Person(){}
	
}
