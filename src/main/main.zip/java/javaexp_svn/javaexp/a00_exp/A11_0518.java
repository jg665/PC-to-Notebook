package javaexp.a00_exp;

import java.util.ArrayList;

import javaexp.z01_vo.Student;

public class A11_0518 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*
1. while문과 do while문의 형식을 기술하고 while문을 통해서 1에서 입력한 범위의 숫자 합을
   아래 형식으로 출력하세요.
   마지막 숫자: @@
   1 + 2 + 3 + 4 + 5 = 11

	- 기본형식 (while) :
	while(반복조건){
		반복 수행할 내용
	}
	- 기본형식 (do while) :
	do{
		일단 1번은 수행하고, 반복조건을 확인하여 반복을 수행할 내용
	}while(반복조건);
	

	Scanner sc = new Scanner(System.in);
	System.out.print("1부터 누적 총합 연산할 마지막 숫자: ");
	int end = sc.nextInt();
	int cnt = 1;
	int sum = 0;
	while(cnt<=end){
		System.out.print(cnt+" + ");
		cnt++;
		sum += cnt;
		if(cnt==end) {
			System.out.print(cnt);
			break;
		}
	}
	System.out.print(" = "+sum);	
	
	답)
	while(cnt<=end){
		sysout(cnt);
		tot+=cnt;
		if(cnt==end){
			sysout(" = "+tot);
		}else{
			sysout(" + ");
		}
		cnt++;
	}
	
	
2. while문을 이용해서 아래와 같이 번호를 선택해서 해당 번호의 물건명과 가격 갯수를 입력,
   총 비용을 출력하세요
   = 메뉴 =
   1. 사이다	800
   2. 콜라	1200
   3. 캔커피	900
   완료하시겠습니까? Y
   1단계) 구매한 물건만 표시 (조건문)
   	답)
		Scanner sc = new Scanner(System.in);
		String buyList = "";
		while(true) {
			System.out.println("= 매뉴 =");
			System.out.println("1. 사이다	800");
			System.out.println("2. 콜라	1200");
			System.out.println("3. 캔커피	900");
			System.out.print("번호를 선택하세요: ");
			int chNum = Integer.parseInt(sc.nextLine());
			System.out.print("선택한 메뉴는 ");
			if(chNum == 1) {
				buyList+="사이다 ";
				// 2단계) 비용과 총비용을 처리시, totPay와 price 변수를 추가하여
				// price = 800;
				// totPay += price;
				System.out.println("사이다");
			}else if(chNum == 2) {
				buyList+="콜라 ";
				System.out.println("콜라");
			}else if(chNum == 3) {
				buyList+="캔커피 ";
				System.out.println("캔커피");
			}else {
				System.out.println("선택의 범위 1~3 사이 번호를 다시 선택해주세요.");
				continue;
			}
			System.out.print("완료하시겠습니까?(Y/N): ");
			if(sc.nextLine().equals("Y")) {
				System.out.println("구매 완료!");
				break;
			}
		}
		System.out.println("# 구매 리스트 내용 #");
		System.out.println(buyList);
   
   2단계) 총비용 표시 (배열)
	Scanner sc = new Scanner(System.in);
	String name = "";
	String priceS = "";
	String prod = "";
	int sum = 0;
	int cnt = 1;
	while(true) {
		System.out.print("물건명: ");
		name = cnt+". "+sc.nextLine();
		System.out.print("가격: ");
		priceS = sc.nextLine();
		sum += Integer.parseInt(priceS);
		prod += name+" "+priceS+"\n";
		System.out.print("완료하시겠습니까?(Y/N): ");
		cnt++;
		if(sc.nextLine().equals("Y")) {
			break;
		}
	}
	System.out.println("= 메뉴 =");
	System.out.println(prod);
	System.out.println("총 비용 : "+sum);    
	
	  
	답)
   		Scanner sc = new Scanner(System.in);
		String []bevs = {"사이다","콜라","캔커피"};
		int []prices = {800, 1200, 900};
		
		
		String buyList = "";
		int totPay = 0;
		while(true) {
			System.out.println("= 매뉴 =");
			System.out.println("1. 사이다	800");
			System.out.println("2. 콜라	1200");
			System.out.println("3. 캔커피	900");
			System.out.print("번호를 선택하세요: ");
			int chNum = Integer.parseInt(sc.nextLine());
			System.out.print("선택한 메뉴는 ");
			if(chNum>=1&&chNum<=3) {
				// 사이다(800) 이렇게 표시된다
				// index 번호와 선택한 번호의 차이 -1
				System.out.println(bevs[chNum-1]+"("+prices[chNum-1]+")");
				buyList+=bevs[chNum-1]+"("+prices[chNum-1]+") ";
				totPay+=prices[chNum-1];
			}else {
				System.out.println("선택의 범위 1~3 사이 번호를 다시 선택해주세요.");
				continue;
			}
			System.out.print("완료하시겠습니까?(Y/N): ");
			if(sc.nextLine().equals("Y")) {
				System.out.println("구매 완료!");
				break;
			}
		}
		System.out.println("# 구매 리스트 내용 #");
		System.out.println(buyList);
		System.out.println("총비용: "+totPay);
   
   3단계) 구매한 물건/갯수/단가/단위계 (ArrayList<Product> 활용)
   		 총계 : @@ 표시
   		 
   답)
      	Scanner sc = new Scanner(System.in);
   		ArrayList<Product> menus = new ArrayList<Product>();
   		menus.add(new Product("사이다",800,0));
   		menus.add(new Product("콜라",1200,0));
   		menus.add(new Product("캔커피",900,0));
   		
   		ArrayList<Product> buyList = new ArrayList<Product>();
   		// 구매리스트 [] - 비어있다
		while(true) {
			System.out.println("= 매뉴 =");
			for(int idx=0;idx<menus.size();idx++) {
				Product menu = menus.get(idx);
				System.out.print(idx+1+"\t");
				System.out.print(menu.getName()+"\t");
				System.out.print(menu.getPrice()+"\n");
			}
			System.out.print("번호를 선택하세요: ");
			int chNum = Integer.parseInt(sc.nextLine());
			System.out.print("선택한 메뉴는 ");
			// 선택메뉴의 범위는 1부터 menulist의 크기까지
			if(chNum>=1&&chNum<=menus.size()) {
				System.out.println("구매할 갯수를 입력하세요.");
				int chCnt = Integer.parseInt(sc.nextLine());
				// 이 중에서 입력한 번호에 해당하는 객체로 선택
				// 입력한 번호에 해당하는 번호를 indx로 가져온다.
				// 메뉴리스트 ((사이다),(콜라),(캔커피)]
				// 선택된 (콜라)객체에 갯수를 할당
				// (콜라, 1200, 4),(캔커피,....),()]
				// 구매리스트[(콜라12333)].
					
				Product chProd = menus.get(chNum-1);
				chProd.setCnt(chCnt);
				System.out.println("# 선택 메뉴 정보 #");
				chProd.totShow();
				// 구매한 ArrayList에 할당.
				buyList.add(chProd);

				// index 번호와 선택한 번호의 차이 -1
				System.out.println(chProd.getName()+"("+chProd.getPrice()+")");
			}else {
				System.out.println("선택의 범위 1~3 사이 번호를 다시 선택해주세요.");
				continue;
			}
			System.out.print("완료하시겠습니까?(Y/N): ");
			if(sc.nextLine().equals("Y")) {
				System.out.println("구매 완료!");
				break;
			}
		}
		System.out.println("# 구매 리스트 내용 #");
		int totPay=0;
		// for(단위 걕체 : 객체형 배열)
		for(Product prod:buyList) {
			// 기능메서드를 통해서 출력과 함께 단위계를 리턴하기 때문에
			// 전체 총계를 누적할 수 있다.
			totPay+=prod.totShow();
		}
		System.out.println("총비용: "+totPay);

3. do while문으로 다음 예제를 진행하세요.
   어서오세요!
   갈비탕(12000) 전문집입니다!
   @@ 회 방문입니다.
   맛나게 먹고갑니다.
   또, 방문하시겠습니까?(Y/N)
   총방문횟수 : @@, 총 지불비용 : @@@

		Scanner sc = new Scanner(System.in);
		int count = 0;
		int tot = 0;
		do {
			System.out.println("어서오세요!");
			System.out.println("갈비탕 (12000)전문집입니다!");
			System.out.println((++count)+"회 방문입니다.");
			System.out.println("맛나게 먹고갑니다.");
			tot=count*12000;
			System.out.print("또, 방문하시겠습니까?(Y/N): ");
		}while(sc.nextLine().equals("Y"));
		System.out.println("총 방문횟수: "+count+", 총 지불비용: "+tot);
		
		답)
		Scanner sc = new Scanner(System.in);
      	int visitNum = 0;
      	int totPay = 0;
      	do {
      		visitNum++;
      		totPay+=12000; // 방문시마다 총비용 누적 처리
      		System.out.println("어서오세요!");
      		System.out.println("갈비탕(12000) 전문점입니다!");
      		System.out.println(visitNum+"@@회 방문입니다.");
      		System.out.println("맛나게 먹고갑니다.");
      		System.out.println("또 방문하시겠습니까?(Y/N)");
      		
      	}while(sc.nextLine().equals("Y"));
      	System.out.println("총방문횟수: "+visitNum+"회, 총 지불비용: "+totPay);
		
4. while/do while을 이용하여 컴퓨터와 함께 하는 임의의 숫자 맞추기 게임
   랜덤에 의해서 임의의 숫자(1~100)를 설정하고 맞출때까지 반복문을 수행하는데
   hint로 보다 크다/보다 작다를 입력시 마다 나오게 처리하세요.
		Scanner sc = new Scanner(System.in);
		int nums [] = new int[100];
		int user = 0;
		int comp = (int)(Math.random()*100+1);
		System.out.println("임의의 숫자 맞추기 게임");
		do {
			System.out.print("정답을 입력하세요: ");
			user = Integer.parseInt(sc.nextLine());
			if(user==comp) {
				System.out.println("정답입니다!");
			}
			if(user>comp) {
				System.out.println("hint: 입력하신 숫자보다 작습니다.");
			}
			if(user<comp) {
				System.out.println("hint: 입력하신 숫자보다 큽니다.");
			}
			System.out.print("정답을 확인하시겠습니까?(Y/N): ");
		}while(sc.nextLine().equals("N"));
		System.out.println("정답: "+comp);   
   		
   		답)
   		Scanner sc = new Scanner(System.in);
		int corNum = 0;
		int ranNum = (int)(Math.random()*100+1);
		System.out.println("# 컴퓨터와 함께하는 숫자 맞추기 게임 #");
		while(true) {
			corNum++;
			System.out.println("번호가 무엇일까요?(1~100): ");
			int inNum = sc.nextInt();
			System.out.println("입력한 번호는 "+inNum);
			if(inNum==ranNum) {
				System.out.println("정답입니다!");
				System.out.println(corNum+"째 성공!");
			}else if(inNum>ranNum) {
				System.out.println("입력된 숫자가 정답보다 큰 수입니다");
			}else {
				System.out.println("입력된 숫자가 정답보다 작은 수입니다");
			}
			
		}
   
5. continue문을 이용하여 1~12월 근무를 하되 3달마다 "SM 유지보수하다"
   그 외에는 "SI 프로그래밍개발을 하다"로 처리하세요.
		System.out.println("# 근무표 #");
		for(int cnt=1;cnt<=12;cnt++) {
			if(cnt%3==0) {
				System.out.println(cnt+"월\tSM 유지보수하다.");
				continue;
			}
			System.out.println(cnt+"월\tSI 프로그래밍개발을 하다.");
		}
		
		답)
		for(int month=1;month<=12;month++) {
			System.out.println(month+"월 ");
			if(month%3==0) {
				System.out.println("SM 유지보수하다");
				continue;
			}
			System.out.println("SI 프로그래밍개발을 하다");
		}

6. Student 클래스에 번호, 국어, 영어, 수학 속성을 할당하고
   학생 5명을 ArrayList<Student>에 담아서 출력하세요
		System.out.println("# 점수표 #");
		System.out.println("번호\t국어\t영어\t수학");
		ArrayList<Student> list = new ArrayList<Student>();
		list.add(new Student(1, 90, 100, 50));
		list.add(new Student(2, 100, 70, 60));
		list.add(new Student(3, 30, 90, 100));
		list.add(new Student(4, 100, 40, 80));
		list.add(new Student(5, 50, 80, 40));
		for(int idx=0;idx<list.size();idx++) {
			System.out.println(list.get(idx).show());
		}
		
		답)
		ArrayList<Student> stList = new ArrayList<Student>();
		System.out.println("번호\t국어\t영어\t수학\t총점\t평균");
		for(int idx=0;idx<5;idx++) {
			int kor = (int)(Math.random()*101);
			int eng = (int)(Math.random()*101);
			int math = (int)(Math.random()*101);
			stList.add(new Student(idx+1,kor,eng,math));
			stList.get(idx).show();
		}
		
		   
		*/		

		
		
	}

}
