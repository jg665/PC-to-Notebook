package javaexp.a00_exp;

public class Team01 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
