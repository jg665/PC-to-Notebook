package javaexp.z00_project;

public class D01_MileageShow {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		A01_MileageController m = new A01_MileageController();
		m.mile(new Mileage("서울","부산","비즈니스","C"), new Model());
		m.mile(new Mileage("서울","부산","비즈니스","U"), new Model());

	
	
	}

}
