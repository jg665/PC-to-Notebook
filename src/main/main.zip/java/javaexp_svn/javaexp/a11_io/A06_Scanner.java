package javaexp.a11_io;

import java.util.Scanner;

public class A06_Scanner {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*
# 간단한 데이터 입력을 처리하는 Scanner 객체 (IO는 아니고 util이지만 간단하게 기능 작동함)
1. 데이터를 입력하여 처리해주는 util 패키지 하위 객체
2. 활용법
	new Scanner(InputStream객체)
	1) 기능 메서드
		next() : 공백전까지 문자열을 입력 (공백 미포함)
		nextLine() : enter키 입력까지 문자열을 입력 (공백 포함됨)
		nextInt() : 정수형 데이터 입력		
		nextDouble() : 실수형 데이터 입력
				*/
/*		Scanner sc = new Scanner(System.in);
		System.out.println("성적 등록");
		System.out.print("이름: ");
		String name = sc.nextLine();
		System.out.print("점수: ");
		int point = sc.nextInt();
		System.out.println("등록할 이름: "+name);
		System.out.println("입력한 점수: "+point);
		if(point>=70) {
			System.out.println("합격");
		}else {
			System.out.println("불합격");
		}
*/		
// ex) 구매할 물건 등록
//	   물건명 :		
//	   가격 :
//	   갯수 :
//	   구매 내역 : @@@ @@@ 총비용 @@@
		
		Scanner pd = new Scanner(System.in);
		System.out.println("구매할 물건 등록");
		System.out.print("물건명 :");
		String pname = pd.nextLine();
		System.out.print("가격 : ");
		int pprice = pd.nextInt();
		System.out.print("갯수 : ");
		int pcnt = pd.nextInt();
		System.out.println("구매내역 : "+pname+", "+pprice+"원에 "+pcnt+"개");
		System.out.println(" 총비용 : "+(pprice*pcnt));
		
		
	}

}
