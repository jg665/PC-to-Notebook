package javaexp.a04_condition;

public class Fruit {
	private String color;
	private String name;
	public Fruit(String color, String name) {
		super();
		this.color = color;
		this.name = name;
	}
	public String show() {
		return name+"("+color+")";
	}
	
	
	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
}
