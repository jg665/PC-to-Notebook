package javaexp.a00_exp;

import java.util.ArrayList;

public class Team01 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<Integer> team = new ArrayList<Integer>();
		for(int cnt=1;cnt<=30;cnt++) {
			team.add(cnt);
		}
		int[][] group1 = new int[5][6];
		for(int idx=0;idx<5;idx++) {
			for(int jdx=0;jdx<6;jdx++) {
				
			}
		}

	}

}
