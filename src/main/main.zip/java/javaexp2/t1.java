package javaexp2;

public class t1 {

	void printgugudan(int dan) {
		
	}
	
	public static void main(String[]args) {
		
		System.out.printf("안녕");
		System.out.printf("안녕");
	}
}
